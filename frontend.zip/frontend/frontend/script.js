
const audioFile = document.getElementById("audioFile");
const audioPlayer = document.getElementById("audioPlayer");
const fileName = document.getElementById("fileName");
const analyzeBtn = document.getElementById("analyzeBtn");
const message = document.getElementById("message");

const gauge = document.getElementById("gauge");
const confidence = document.getElementById("confidence");
const verdict = document.getElementById("verdict");
const description = document.getElementById("description");
const signal = document.getElementById("signal");
const meterFill = document.getElementById("meterFill");
const results = document.getElementById("results");

const API_URL = "http://127.0.0.1:8000/analyze";

let audioURL = null;

audioFile.addEventListener("change", () => {
  const file = audioFile.files[0];

  if (!file) return;

  if (audioURL) {
    URL.revokeObjectURL(audioURL);
  }

  audioURL = URL.createObjectURL(file);
  audioPlayer.src = audioURL;
  audioPlayer.hidden = false;

  fileName.textContent = file.name;
  analyzeBtn.disabled = false;

  message.textContent = "Audio loaded. Ready for AI analysis.";

  confidence.textContent = "--%";
  verdict.textContent = "AWAITING ANALYSIS";
  description.textContent =
    "Run the detector to receive a result.";

  gauge.style.background =
    "conic-gradient(#35df91 0deg, #292e3a 0deg)";

  meterFill.style.width = "0%";
  signal.style.color = "";
});

function showResult(score) {
  let color;
  let title;
  let details;

  if (score >= 70) {
    color = "#ff454f";
    title = "HIGH RISK";
    details =
      "Strong indication of AI-generated or cloned audio. Verify before trusting.";
  } else if (score >= 40) {
    color = "#ffc247";
    title = "UNCERTAIN";
    details =
      "The result is inconclusive. Further analysis is recommended.";
  } else {
    color = "#35df91";
    title = "LOW RISK";
    details =
      "The detector found limited evidence of AI-generated audio.";
  }

  document.documentElement.style.setProperty("--active", color);

  confidence.textContent = `${score.toFixed(2)}%`;
  verdict.textContent = title;
  description.textContent = details;
  signal.style.color = color;

  gauge.style.background =
    `conic-gradient(${color} ${score * 3.6}deg, #292e3a 0deg)`;

  meterFill.style.width = `${score}%`;
  meterFill.style.background = color;
  results.style.borderTopColor = color;
}

analyzeBtn.addEventListener("click", async () => {
  const file = audioFile.files[0];

  if (!file) {
    message.textContent = "Please select an audio file first.";
    return;
  }

  analyzeBtn.disabled = true;
  message.textContent = "Sending audio to VoiceGuardAI...";

  verdict.textContent = "ANALYZING";
  description.textContent =
    "The AI model is examining your audio.";

  try {
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch(API_URL, {
      method: "POST",
      body: formData
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "The AI analysis failed.");
    }

    console.log("VoiceGuardAI response:", data);

    const fakeScore = Number(data.scores?.fake);

    if (
      !Number.isFinite(fakeScore) ||
      !["real", "fake"].includes(data.prediction)
    ) {
      throw new Error("The API returned an unexpected result.");
    }

    showResult(fakeScore);

    if (data.prediction === "fake") {
      verdict.textContent = "FAKE AUDIO DETECTED";
      description.textContent =
        `The model classified this audio as fake. ` +
        `Fake-class score: ${fakeScore.toFixed(2)}%.`;
    } else {
      verdict.textContent = "REAL AUDIO DETECTED";
      description.textContent =
        `The model classified this audio as real. ` +
        `Fake-class score: ${fakeScore.toFixed(2)}%. ` +
        "Automated detection is not a guarantee of authenticity.";
    }

    message.textContent =
      `Analysis complete: ${data.filename || file.name}`;

  } catch (error) {
    console.error("VoiceGuardAI error:", error);

    message.textContent =
      `Analysis failed: ${error.message}`;

    verdict.textContent = "ANALYSIS FAILED";
    description.textContent =
      "The detector could not complete the analysis. Please try again.";

  } finally {
    analyzeBtn.disabled = false;
  }
});
